var n = prompt("informe a quatidade de numeros:");
var numeros;
var soma = 0;
var i = 0;

//utilizar o parseInt para definir a natureza do dado como inteiro e não String;
while (i < n) {
  numeros = parseInt(prompt("informe o numero:"));
  soma = soma + numeros;
  i = i + 1;
}

document.write("a soma dos " + n + " numeros é: " + soma);
