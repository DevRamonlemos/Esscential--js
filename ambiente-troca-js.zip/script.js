var a = prompt("informe valor para a variavel A");
var b = prompt("informe valor para a variavel B");

var aux;

aux = a
a = b
b = aux;

document.write("novo valor de A:" + a + "<br>");
document.write("novo valor de b: " + b);
