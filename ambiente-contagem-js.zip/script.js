var n = prompt("informe a quantidade de alunos");
var nota;
var contador = 0;
var i = 0;

while (i < n) {
  nota = prompt("informe a nota do aluno ");

  if (nota >= 50) {
    contador++;
  }
  i++;
}
document.write("numero de alunos que passaram no exame: " + contador);
